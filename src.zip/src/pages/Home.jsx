import React, { useEffect, useState } from "react";
import Movie from "../components/movie";
import { getTrending } from "../query/trending";
import styled from "styled-components";

const MovieContainer = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-evenly;
  align-items: center;
  flex-wrap: wrap;
  padding-top: 5rem;
`;

const App = () => {
  const [trendingMovies, setTrendingMovies] = useState([]);

  useEffect(() => {
    const fetchTrendingMovies = async () => {
      const movies = await getTrending();
      setTrendingMovies(movies);
    };
    fetchTrendingMovies();
  }, []);

  return (
    <>
      <MovieContainer>
        {trendingMovies.map((movie) => (
          <Movie
            title={movie.title}
            rating={movie.vote_average}
            poster={movie.poster_path}
            overview={movie.overview}
          />
        ))}
      </MovieContainer>
    </>
  );
};

export default App;
