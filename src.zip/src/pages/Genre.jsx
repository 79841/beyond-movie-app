import React, { useState } from "react";
import { useEffect } from "react";
import { getGenres, getMoviesByGenre } from "../query/genre";
import { styled } from "styled-components";

const Container = styled.div`
  display: flex;
`;

const Genre = () => {
  const [genres, setGenres] = useState([]);

  useEffect(() => {
    const fetchGenres = async () => {
      const genres = await getGenres();
      console.log(genres);
      setGenres(genres);
    };
    fetchGenres();
  }, []);

  return (
    <div>
      {genres.map(async (genre) => {
        const movies = await getMoviesByGenre(genre.id);
        console.log(movies);
        return <div>{genre.name}</div>;
      })}
    </div>
  );
};

export default Genre;
