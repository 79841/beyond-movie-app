import React from "react";
import { Link } from "react-router-dom";
import styled from "styled-components";

const Container = styled.nav`
  display: flex;
  flex-direction: column;
  justify-content: center;
  height: 100vh;
  position: fixed;
  left: 0;

  ul {
    list-style: none;
  }
`;

const StyledLink = styled(Link)`
  text-decoration: none;
  font-size: 1.5rem;
  color: black;
  &:hover {
    color: black;
  }
`;

const Nav = () => {
  return (
    <nav>
      <Container>
        <ul>
          <li>
            <StyledLink to="/">Home</StyledLink>
          </li>
          <li>
            <StyledLink to="/genre">Genre</StyledLink>
          </li>
        </ul>
      </Container>
    </nav>
  );
};

export default Nav;
