import React from "react";
import { BASE_IMAGE_URL } from "../const";
import styled from "styled-components";

const Container = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: start;
  align-items: center;
  width: 30rem;
  height: 70rem;
`;

const Movie = ({ title, poster, overview, rating }) => {
  return (
    <Container>
      <img src={BASE_IMAGE_URL + poster} alt={title} />
      <div className="rating">{rating}</div>
      <div className="title">{title}</div>
      <div className="overview">{overview}</div>
    </Container>
  );
};

export default Movie;
