import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "./pages/Home";
import styled from "styled-components";
import Nav from "./components/Nav";
import Genre from "./pages/Genre";

const Container = styled.div`
  display: flex;
  padding-left: 10rem;
`;

const App = () => {
  return (
    <Container>
      <BrowserRouter>
        <Nav />
        <Routes>
          <Route exact path="/" element={<Home />} />
          <Route exact path="/genre" element={<Genre />} />
        </Routes>
      </BrowserRouter>
    </Container>
  );
};

export default App;
